import { h, Component } from 'preact';

export default class Footer extends Component {

  render({}, {}) {
    return (
      <div>
        <section class="body-footer">
          <p class="no-margin-vertical">Powered By <strong>Selenite</strong></p>
        </section>
      </div>
    );
  }
}
